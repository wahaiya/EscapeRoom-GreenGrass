let active = []

var showDiv = [];

for (var i = 1; i < 30; i++) {
  showDiv.push("hidden");
}


function connect() {
  var connection = new WebSocket('wss://6n5wzcue6h.execute-api.ap-northeast-1.amazonaws.com/production');
  connection.onopen = function() {
    console.log("Reconnected, connection is open and ready to use");
    };
  };

var connection = new WebSocket('wss://6n5wzcue6h.execute-api.ap-northeast-1.amazonaws.com/production');
connection.onopen = function () {
  console.log("connection is open and ready to use");
};

connection.onclose = function (error) {
  console.log('Socket is closed. Reconnect will be attempted in 1 second.', error.reason);
    setTimeout(function() {
      connect();
    }, 1000);
};

connection.onerror = function (error) {
  console.log('Socket is on error state. Reconnect will be attempted in 1 second.', error.reason);
    setTimeout(function() {
      connect();
    }, 1000);
};


let boothFrameController = {
  view: () => {
    return m("div", {class: "flex-container"}, [
        m("div", {class: 'div1', style: {visibility: showDiv[1]}}),
        m("div", {class: 'div2', style: {visibility: showDiv[2]}}),
        m("div", {class: 'div3', style: {visibility: showDiv[3]}}),
        m("div", {class: 'div4', style: {visibility: showDiv[4]}}),
        m("div", {class: 'div5', style: {visibility: showDiv[5]}}),
        m("div", {class: 'div6', style: {visibility: showDiv[6]}}),
        m("div", {class: 'div7', style: {visibility: showDiv[7]}}),
        m("div", {class: 'div8', style: {visibility: showDiv[8]}}),
        m("div", {class: 'div9', style: {visibility: showDiv[9]}}),
        m("div", {class: 'div10', style: {visibility: showDiv[10]}}),
        m("div", {class: 'div11', style: {visibility: showDiv[11]}}),
        m("div", {class: 'div12', style: {visibility: showDiv[12]}}),
        m("div", {class: 'div13', style: {visibility: showDiv[13]}}),
        m("div", {class: 'div14', style: {visibility: showDiv[14]}}),
        m("div", {class: 'div15', style: {visibility: showDiv[15]}}),
        m("div", {class: 'div16', style: {visibility: showDiv[16]}}),
        m("div", {class: 'div17', style: {visibility: showDiv[17]}}),
        m("div", {class: 'div18', style: {visibility: showDiv[18]}}),
        m("div", {class: 'div19', style: {visibility: showDiv[19]}}),
        m("div", {class: 'div20', style: {visibility: showDiv[20]}}),
        m("div", {class: 'div21', style: {visibility: showDiv[21]}}),
        m("div", {class: 'div22', style: {visibility: showDiv[22]}}),
        m("div", {class: 'div23', style: {visibility: showDiv[23]}}),
        m("div", {class: 'div24', style: {visibility: showDiv[24]}}),
        m("div", {class: 'div25', style: {visibility: showDiv[25]}}),
        m("div", {class: 'div26', style: {visibility: showDiv[26]}}),
        m("img", {class: 'center', src: "escaperoom.png", width: "1660px", height: "1080px" }), 
    ])
  }
}

connection.onopen = function () {
  console.log("connection is open and ready to use")
  setInterval(() => {
    connection.send(`{"type":"ping","message":"ping architecture"}`);
  }, 8000)
};

connection.onerror = function (error) {
  console.log("an error occurred when sending/receiving data")
};

function lightUp(divName, milis) {
  setTimeout(() => { showDiv[divName] = "hidden";  m.redraw(); }, milis);
  showDiv[divName] = "visible"; 
  m.redraw();
}

connection.onmessage = (message) => {
  try {
    console.log(message.data);
  if(message.data == "MainScreen"){  
    lightUp(1, 6000);
    lightUp(2, 6000);
    return; 
  } 
  if(message.data == "switchCode"){  
    lightUp(3, 6000);
    lightUp(4, 6000);
    lightUp(5, 6000);
    lightUp(6, 6000);
    lightUp(13, 6000);
    lightUp(14, 6000);
    lightUp(23, 6000);
    lightUp(24, 6000);
    lightUp(25, 6000);
    lightUp(26, 6000);
    return; 
  } 
  if(message.data == "Passcode"){  
    lightUp(20, 6000);
    lightUp(21, 6000);
    lightUp(22, 6000);
    lightUp(19, 6000);
    lightUp(12, 6000);
    lightUp(6, 6000);
    lightUp(23, 6000);
    lightUp(24, 6000);
    lightUp(25, 6000);
    lightUp(26, 6000);
    return; 
  } 
  if(message.data == "Celebrity"){  
    lightUp(13, 6000);
    lightUp(14, 6000);
    lightUp(3, 6000);
    lightUp(4, 6000);
    lightUp(5, 6000);
    lightUp(7, 6000);
    lightUp(12, 6000);
    lightUp(23, 6000);
    lightUp(24, 6000);
    lightUp(25, 6000);
    lightUp(26, 6000);
    return; 
  } /*
  if(message.data == "Celebrity Not Recognized"){  
    lightUp(13, 6000);
    lightUp(14, 6000);
    lightUp(15, 6000);
    lightUp(16, 6000);
    lightUp(3, 6000);
    lightUp(17, 6000);
    lightUp(18, 6000);
    lightUp(19, 6000);
    lightUp(12, 6000);
    return; 
  } */
  if(message.data == "OK - Authorized Personnel Detected"){  
    lightUp(13, 6000);
    lightUp(14, 6000);
    lightUp(15, 6000);
    lightUp(16, 6000);
    lightUp(3, 6000);
    lightUp(17, 6000);
    lightUp(18, 6000);
    lightUp(19, 6000);
    lightUp(12, 6000);
    lightUp(23, 6000);
    lightUp(24, 6000);
    lightUp(25, 6000);
    lightUp(26, 6000);
    return; 
  } 
  if(message.data == "nextQuestion"){  
    lightUp(13, 6000);
    lightUp(14, 6000);
    lightUp(3, 6000);
    lightUp(4, 6000);
    lightUp(8, 6000);
    return; 
  } 
  if(message.data == "questionRight"){  
    lightUp(13, 6000);
    lightUp(14, 6000);
    lightUp(3, 6000);
    lightUp(4, 6000);
    lightUp(10, 6000);
    return; 
  } 
  if(message.data == "questionWrong"){  
    lightUp(13, 6000);
    lightUp(14, 6000);
    lightUp(3, 6000);
    lightUp(4, 6000);
    lightUp(11, 6000);
    return; 
  } 
  if(message.data == "timeUp" || message.data == "challengeCompleted"){  
    lightUp(1, 8000);
    lightUp(2, 8000);
    lightUp(3, 8000);
    lightUp(4, 8000);
    lightUp(5, 8000);
    lightUp(6, 8000);
    lightUp(7, 8000);
    lightUp(8, 8000);
    lightUp(9, 8000);
    lightUp(10, 8000);
    lightUp(11, 8000);
    lightUp(12, 8000);
    lightUp(13, 8000);
    lightUp(14, 8000);
    lightUp(15, 8000);
    lightUp(16, 8000);
    lightUp(17, 8000);
    lightUp(18, 8000);
    lightUp(19, 8000);
    lightUp(20, 8000);
    lightUp(21, 8000);
    lightUp(22, 8000);
    lightUp(23, 8000);
    lightUp(24, 8000);
    lightUp(25, 8000);
    lightUp(26, 8000);
    setTimeout(() => { window.location.reload(); }, 8000);
  return; 
  } 
  if(message.data == "Reset"){  
    lightUp(1, 8000);
    lightUp(2, 8000);
    lightUp(3, 8000);
    lightUp(4, 8000);
    lightUp(5, 8000);
    lightUp(6, 8000);
    lightUp(7, 8000);
    lightUp(8, 8000);
    lightUp(9, 8000);
    lightUp(10, 8000);
    lightUp(11, 8000);
    lightUp(12, 8000);
    lightUp(13, 8000);
    lightUp(14, 8000);
    lightUp(15, 8000);
    lightUp(16, 8000);
    lightUp(17, 8000);
    lightUp(18, 8000);
    lightUp(19, 8000);
    lightUp(20, 8000);
    lightUp(21, 8000);
    lightUp(22, 8000);
    lightUp(23, 8000);
    lightUp(24, 8000);
    lightUp(25, 8000);
    lightUp(26, 8000);
    setTimeout(() => { window.location.reload(); }, 8000);
    
    return; 
  } 
  
  
    
  } catch (e) {
    console.log(e);
    return;
  }
}

m.mount(document.body, boothFrameController, {active})
