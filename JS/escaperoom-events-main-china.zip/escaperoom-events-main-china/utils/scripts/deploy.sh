cd /home/mainscreen/Desktop/
rm -rf /home/mainscreen/Desktop/escaperoom-events /home/mainscreen/Desktop/__MACOSX/ /home/mainscreen/Desktop/mainscreen/
aws s3 cp s3://escaperoom-artifacts/escaperoom-events.zip /home/mainscreen/Desktop/
unzip escaperoom-events.zip
rm -rf /home/mainscreen/Desktop/__MACOSX/
chmod -R 777 /home/mainscreen/Desktop/escaperoom-events
mv /home/mainscreen/Desktop/escaperoom-events/mainscreen /home/mainscreen/Desktop/
rm -rf /home/mainscreen/Desktop/escaperoom-events/
rm /home/mainscreen/Desktop/escaperoom-events.zip
chown -R mainscreen:mainscreen /home/mainscreen/Desktop/mainscreen
sh /root/start.sh