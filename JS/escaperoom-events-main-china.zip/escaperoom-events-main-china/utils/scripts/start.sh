killall chrome
su - mainscreen -c "export DISPLAY=:0.0 && nohup chromium-browser --kiosk --incognito --disable-pinch --overscroll-history-navigation=0 /home/mainscreen/Desktop/mainscreen/index.html &"