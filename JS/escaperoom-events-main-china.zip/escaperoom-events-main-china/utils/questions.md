question about rekognition
question about celebrity rekognition
question about serverless
question about S3
question about machine learning
question about IoT
question about EC2
question about Setting an account on AWS
question about the new region
question about general AWS