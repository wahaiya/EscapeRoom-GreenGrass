function connect() {
  var connection = new WebSocket('wss://6n5wzcue6h.execute-api.ap-northeast-1.amazonaws.com/production');
  connection.onopen = function() {
    console.log("Reconnected, connection is open and ready to use");
    };
  };

var connection = new WebSocket('wss://6n5wzcue6h.execute-api.ap-northeast-1.amazonaws.com/production');
connection.onopen = function () {
  console.log("connection is open and ready to use");
};

connection.onclose = function (error) {
  console.log('Socket is closed. Reconnect will be attempted in 1 second.', error.reason);
    setTimeout(function() {
      connect();
    }, 1000);
};

connection.onerror = function (error) {
  console.log('Socket is on error state. Reconnect will be attempted in 1 second.', error.reason);
    setTimeout(function() {
      connect();
    }, 1000);
};

let active = []
let challengeGameStart = "";
let challenge1 = "";
let challenge2 = "";
let challenge3= ""
let challenge4= ""
let challengeGameFinish = "";

setInterval(function () {
  async function fetchData() {
    const response = await fetch('https://u0opoq2u64.execute-api.ap-northeast-1.amazonaws.com/getGameStats', {
          method: "GET",
          mode: "cors",
          cache: "no-cache",
    }
    );
    const data = await response.json();
    return data;
  }

fetchData().then(data => {


const now = Date.now();
const screen1Lantency = (now - window.MainScreenLastContact)/1000;
const screen2Lantency = (now - window.TouchScreenLastContact)/1000;
const switchLantency = (now - window.SwitchLastContact)/1000;
const cameraLatency = (now - window.cameraLastContact)/1000;
const relayLatency = (now - window.relayLastContact)/1000;


let boothFrameController = {
  view: () => {
    return m("div", {class: "flex-container"}, [
      m("h1", "Challenges:"),
      m("h1", "--------------------"),
      m("h1", "Game Start: "+challengeGameStart),
      m("h1", "Challenge 1: "+challenge1),
      m("h1", "Challenge 2 "+challenge2),
      m("h1", "Challenge 3: "+challenge3),
      m("h1", "Challenge 4: "+challenge4),
      m("h1", "Game Finish: "+challengeGameFinish),
      m("h1", "---------------------"),
      m("h1", "Games Played: "+data.played_games),
      m("h1", "Games Passed: "+data.passed_games),
      m("h1", "Games Failed: "+data.failed_games),
      m("h1", "Avg Escape Time: "+data.timeToEscape+" sec"),
      m("h1", "--------------------"),
      m("h1", "Latency:"),
      m("h1", "Screen1: "+screen1Lantency), 
      m("h1", "Screen2: "+screen2Lantency), 
      m("h1", "Switch: "+switchLantency), 
      m("h1", "Camera: "+cameraLatency), 
      m("h1", "Relay: "+relayLatency), 
    ])
  }
}

connection.onopen = function () {
  console.log("connection is open and ready to use")
};

connection.onerror = function (error) {
  console.log("an error occurred when sending/receiving data")
};

connection.onmessage = (message) => {
  try {
    console.log(message.data);
    if (message.data == "MainScreen") {
      window.MainScreenLastContact = Date.now();
    }
    if (message.data == "TouchScreen") {
      window.TouchScreenLastContact = Date.now();
    }
    if (message.data == "EscapeRoomSwitch") {
      window.SwitchLastContact = Date.now();
    }
    if (message.data == "Celebrity Not Recognized") {
      window.cameraLastContact = Date.now();
    }
    if (message.data == "OK - Authorized Personnel Detected") {
      window.cameraLastContact = Date.now();
    }
    if (message.data == "EscapeRoomRelay") {
      window.relayLastContact = Date.now();
    }

    if(message.data == "switchCode"){  
        showDemo = "visible"; 
        showCountdown = "visible"; 
        iframeLeaderBoardURL = "./modules/leaderboard/index.html";
        iFrameChallengesURL = "./modules/challenges/index.html";
        iFrameCountdownURL = "./modules/countdown/index.html";
        challengeGameStart = "Game Started";
        challenge1 = "In Progress";
        
        challengeGameFinish = "";
        m.redraw();
      return; 
    } 
    if(message.data == "Passcode"){  
      showDemo = "visible"; 
      showCountdown = "hidden"; 
      iFrameURL = "./modules/clock/index.html";
      iFrameCountdownURL = "";
      challenge1 = "Completed";
      challenge2 = "In Progress";
      m.redraw();
    return; 
  } 
  if(message.data == "Celebrity"){  
    showDemo = "visible"; 
    iFrameURL = "./modules/celebrity-rekognition/index.html";
    challenge1 = "Completed";
    challenge2 = "Completed";
    challenge3= "In Progress";
    m.redraw();
  return; 
  } 
  if(message.data == "OK - Authorized Personnel Detected"){  
    showDemo = "visible"; 
    iFrameURL = "./modules/trivia/index.html";
    challenge1 = "Completed";
    challenge2 = "Completed";
    challenge3= "Completed";
    challenge4= "In Progress";
    m.redraw();
  return; 
  } 
  if(message.data == "timeUp"){  
    showDemo = "visible"; 
    showCountdown = "hidden"; 
    iFrameURL = "./modules/timeisup/index.html";
    challengeGameStart = "Time's Up";
    challenge1 = "Time's Up";
    challenge1 = "Time's Up";
    challenge2 = "Time's Up";
    challenge3= "Time's Up";
    challenge4= "Time's Up";
    challengeGameFinish= "Time's Up";
    m.redraw();
  return; 
  } 
  if(message.data == "challengeCompleted"){  
    showDemo = "visible"; 
    iFrameURL = "./modules/challenge-completed/index.html";
    challenge1 = "Completed";
    challenge2 = "Completed";
    challenge3= "Completed";
    challenge4= "Completed";
    challengeGameFinish= "Game Completed";
    m.redraw();
  return; 
  } 
  if(message.data == "Reset"){  
    showDemo = "visible"; 
    showCountdown = "hidden"; 
    iFrameURL = "./modules/clock/index.html";
    iFrameCountdownURL = "";
    challengeGameStart = "Awaiting";
    challenge1 = "";
    challenge2 = "";
    challenge3= ""
    challengeGameFinish = "";
    m.redraw();
  return; 
} 
    
  } catch (e) {
    console.log(e,
      message.data);
    return;
  }
}


m.mount(document.body, boothFrameController, {active})
});

}, 1000)