function playHint() {
    const box = document.getElementById('button-hint');
    box.style.visibility = 'hidden';
    const music = new Audio('light_into_the_room.mp3');
    music.play();
    setTimeout(() => { box.style.visibility = 'visible'; }, 3000);
  }