$('input').click(function(){
  return false;
});

var pass = '159311',
    temp = '',
    pressed = 0,
    press_max = 6;

$('.button-num').click(function(){
  
  pressed++;
  
  if(pressed <= press_max){
    $($('input')[pressed-1]).prop('checked', true);
    temp += $(this).attr("id").split('-')[1];
  }
  
});
var timer,
    timerduration = 300,
    shake = 10;

$('#button-e').click(function(){

  $.post( "https://u0opoq2u64.execute-api.ap-northeast-1.amazonaws.com/touchScreenPassword?password="+temp+"")
  .done(function( data ) {
    if (data === "\"Password OK\"") {
      temp = '159311';
    }
    if (data === "\"Password ERROR\"") {
      temp = '1234';
    }
  
  if(pass == temp){
    
    pressed = 0;
    temp = '';
    $('input').prop('checked', false);
    
    clearTimeout(timer);
    timer = setTimeout(function(){
      $('#complete').transition({ rotateY : 180, duration: timerduration });
      $('#numpad').transition({ rotateY : 0, duration: timerduration });
    }, timerduration*10)
    
    $('#complete').transition({ rotateY : 0, duration: timerduration });
    $('#numpad').transition({ rotateY : 180, duration: timerduration });
      $('#notice').html("Enter passcode to Begin");
    
    pressed = 0;
    temp = '';
    $('input').prop('checked', false);
    
  } else {
    
    $('#numpad')
      .transition({ x: shake, duration: timerduration/5 })
      .transition({ x: -shake, duration: timerduration/5 })
      .transition({ x: shake, duration: timerduration/5 })
      .transition({ x: -shake, duration: timerduration/5 })
      .transition({ x: 0, duration: timerduration/5 });
    
      clearTimeout(timer);
      $('#notice').html("Wrong Passcode!");
    
      timer = setTimeout(function(){
        pressed = 0;
        temp = '';
        $('input').prop('checked', false);
      }, timerduration);
    
  }
  });
});

$('#button-hint').click(function(){
  function randomIntFromInterval(min, max) { // min and max included 
    return Math.floor(Math.random() * (max - min + 1) + min)
  }
  const rndInt = randomIntFromInterval(1, 2)
  const box = document.getElementById('button-hint');
  box.style.visibility = 'hidden';
  if (rndInt == 1) {
    const music = new Audio('six_digit_code.mp3');
    music.play();;
    setTimeout(() => { box.style.visibility = 'visible'; }, 5000);
  }
  if (rndInt == 2) {
    const music = new Audio('time_is_essential.mp3');
    music.play();
    setTimeout(() => { box.style.visibility = 'visible'; }, 5000);
  }
  
});

$('#button-c').click(function(){
  
  if(pressed > 0){
    $($('input')[pressed-1]).prop('checked', false);
    pressed--;
    temp = temp.slice(0,pressed);
  }
  
});