function connect() {
  var connection = new WebSocket('wss://6n5wzcue6h.execute-api.ap-northeast-1.amazonaws.com/production');
  connection.onopen = function() {
    console.log("Reconnected, connection is open and ready to use");
    };
  };
var connection = new WebSocket('wss://6n5wzcue6h.execute-api.ap-northeast-1.amazonaws.com/production');
connection.onopen = function () {
  console.log("connection is open and ready to use");
};

connection.onclose = function (error) {
  console.log('Socket is closed. Reconnect will be attempted in 1 second.', error.reason);
    setTimeout(function() {
      connect();
    }, 1000);
};

connection.onerror = function (error) {
  console.log('Socket is on error state. Reconnect will be attempted in 1 second.', error.reason);
    setTimeout(function() {
      connect();
    }, 1000);
};

async function fetchEscapeRoomData() {
  const response = await fetch('https://u0opoq2u64.execute-api.ap-northeast-1.amazonaws.com/getQuestions', {
        method: "GET", // POST
        mode: "cors",
        cache: "no-cache",
  });
  const data = await response.json();
  //const data = await response;
  return data;
} 


function challengeCompleted(){
  fetch("https://u0opoq2u64.execute-api.ap-northeast-1.amazonaws.com/touchScreenPassword?password=challengeCompleted", {
    method: "POST",
    mode: "cors",
    cache: "no-cache",
    });
}

function checkAnswer(answeredQuestion, currentQuestion, questionIsRight){
  document.getElementById("questionButton1").disabled = true;
  document.getElementById("questionButton2").disabled = true;
  document.getElementById("questionButton3").disabled = true;
  document.getElementById("questionButton4").disabled = true;
  if (currentQuestion === 999) {
    fetch("https://u0opoq2u64.execute-api.ap-northeast-1.amazonaws.com/touchScreenPassword?password=nextQuestion", {
    method: "POST",
    mode: "cors",
    cache: "no-cache",
    });
    setTimeout(function() { document.getElementById("questionButton1").disabled = false; }, 500);
    setTimeout(function() { document.getElementById("questionButton2").disabled = false; }, 500);
    setTimeout(function() { document.getElementById("questionButton3").disabled = false; }, 500);
    setTimeout(function() { document.getElementById("questionButton4").disabled = false; }, 500);
  } else {
    if (answeredQuestion == questionIsRight) {
      fetch("https://u0opoq2u64.execute-api.ap-northeast-1.amazonaws.com/touchScreenPassword?password=questionRight", {
      method: "POST",
      mode: "cors",
      cache: "no-cache",
      });
    } else {
      fetch("https://u0opoq2u64.execute-api.ap-northeast-1.amazonaws.com/touchScreenPassword?password=questionWrong", {
      method: "POST",
      mode: "cors",
      cache: "no-cache",
      });
    }
    setTimeout(function() { document.getElementById("questionButton1").disabled = false; }, 3000);
    setTimeout(function() { document.getElementById("questionButton2").disabled = false; }, 3000);
    setTimeout(function() { document.getElementById("questionButton3").disabled = false; }, 3000);
    setTimeout(function() { document.getElementById("questionButton4").disabled = false; }, 3000);
  }
  
}



fetchEscapeRoomData().then(data => {
  console.log(data.Items);
  questionsAmount = data.Count-1;
  questionBody = data.Items[0];
  questionIsRight = 0
  currentQuestion = 999;
  questionsRight = 0;
  questionAnswer1 = "按任意键开始"
  questionAnswer2 = "1"
  questionAnswer3 = "2"
  questionAnswer4 = "3"
  let escapeRoomController = {
    view: () => {
      return m("main", [
          m("div", [
            m("br"),m("br"),m("br"),m("br"),m("br"),m("br"),m("br"),m("br"),m("br"),
            m("button", {id: "questionButton1", onclick: function(){checkAnswer(1, currentQuestion, questionIsRight);}}, [m("h2", questionAnswer1)]),
            m("br"),
            m("button", {id: "questionButton2", onclick: function(){checkAnswer(2, currentQuestion, questionIsRight);}}, [m("h2", questionAnswer2)]),
            m("br"),
            m("button", {id: "questionButton3", onclick: function(){checkAnswer(3, currentQuestion, questionIsRight);}}, [m("h2", questionAnswer3)]),
            m("br"),
            m("button", {id: "questionButton4", onclick: function(){checkAnswer(4, currentQuestion, questionIsRight);}}, [m("h2", questionAnswer4)]),
          ]),
      ])
    }
  }

connection.onmessage = (message) => {
  try {
    console.log("questionsAmount " + questionsAmount);
    console.log("currentQuestion " + currentQuestion);
    console.log(data.Items);
    console.log(message.data);
    if(message.data == "nextQuestion"){  
      currentQuestion = 0;
      questionAnswer1 = data.Items[currentQuestion].questionAnswer1
      questionAnswer2 = data.Items[currentQuestion].questionAnswer2
      questionAnswer3 = data.Items[currentQuestion].questionAnswer3
      questionAnswer4 = data.Items[currentQuestion].questionAnswer4
      questionIsRight = data.Items[currentQuestion].questionIsRight
      m.redraw();
      return; 
    } 
    if(message.data == "questionRight"){  
      setTimeout(() => {
        currentQuestion = currentQuestion + 1;
        if (currentQuestion > questionsAmount) { 
          currentQuestion = 0;
          console.log("Questions roundtrip");
        }
        console.log("questions right");
        questionAnswer1 = data.Items[currentQuestion].questionAnswer1
        questionAnswer2 = data.Items[currentQuestion].questionAnswer2
        questionAnswer3 = data.Items[currentQuestion].questionAnswer3
        questionAnswer4 = data.Items[currentQuestion].questionAnswer4
        questionIsRight = data.Items[currentQuestion].questionIsRight
        questionsRight = questionsRight + 1;
        if (questionsRight === 3) {
          challengeCompleted();
          return;
        }
        
        console.log(questionsRight);
        m.redraw();
      }, 2500);
      return; 
    } 
    if(message.data == "questionWrong"){  
      setTimeout(() => {
        currentQuestion = currentQuestion + 1;
        if (currentQuestion > questionsAmount) { 
          currentQuestion = 0;
          console.log("Questions roundtrip");
        }
        console.log("questions wrong");
        questionAnswer1 = data.Items[currentQuestion].questionAnswer1
        questionAnswer2 = data.Items[currentQuestion].questionAnswer2
        questionAnswer3 = data.Items[currentQuestion].questionAnswer3
        questionAnswer4 = data.Items[currentQuestion].questionAnswer4
        questionIsRight = data.Items[currentQuestion].questionIsRight
        m.redraw();
      }, 2500);
    return; 
    }    
  } catch (e) {
    console.log(e);
    return;
  }
}
m.mount(document.body, escapeRoomController)
});  