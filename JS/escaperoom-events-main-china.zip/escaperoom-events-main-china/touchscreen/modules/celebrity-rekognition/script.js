function playHint() {
    function randomIntFromInterval(min, max) { // min and max included 
        return Math.floor(Math.random() * (max - min + 1) + min)
      }
      const rndInt = randomIntFromInterval(1, 2)
      const box = document.getElementById('button-hint');
      box.style.visibility = 'hidden';
      if (rndInt == 1) {
        const music = new Audio('rekognition.mp3');
        music.play();
        setTimeout(() => { box.style.visibility = 'visible'; }, 18000);
      }
      if (rndInt == 2) {
        const music = new Audio('celebrity_rekognition.mp3');
        music.play();
        setTimeout(() => { box.style.visibility = 'visible'; }, 15000);
      }

}