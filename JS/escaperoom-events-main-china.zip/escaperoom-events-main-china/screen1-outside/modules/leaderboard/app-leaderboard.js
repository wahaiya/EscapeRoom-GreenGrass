setInterval(function () {
    async function fetchData() {
      const response = await fetch('https://u0opoq2u64.execute-api.ap-northeast-1.amazonaws.com/getLeaderBoard', {
            method: "GET",
            mode: "cors",
            cache: "no-cache",
      }
      );
      const data = await response.json();
      return data;
    }
    fetchData().then(data => {
      let completedTime1 = "-"
      let completedTime2 = "-"
      let completedTime3 = "-"
      let completedTime4 = "-"
      let completedTime5 = "-"
      let completedTime6 = "-"
      let completedTime7 = "-"
      let completedTime8 = "-"
      let completedTime9 = "-"
      let completedTime10 = "-"

      leaderBoard = data.Items.sort(function(a, b){ return a.completedTime - b.completedTime; });
      if (data.Items[0]) { completedTime1 = data.Items[0].completedTime } else  { completedTime1 = "N/A"}
      if (data.Items[1]) { completedTime2 = data.Items[1].completedTime } else  { completedTime2 = "N/A"}
      if (data.Items[2]) { completedTime3 = data.Items[2].completedTime } else  { completedTime3 = "N/A"}
      if (data.Items[3]) { completedTime4 = data.Items[3].completedTime } else  { completedTime4 = "N/A"}
      if (data.Items[4]) { completedTime5 = data.Items[4].completedTime } else  { completedTime5 = "N/A"}
      if (data.Items[5]) { completedTime6 = data.Items[5].completedTime } else  { completedTime6 = "N/A"}
      if (data.Items[6]) { completedTime7 = data.Items[6].completedTime } else  { completedTime7 = "N/A"}
      if (data.Items[7]) { completedTime8 = data.Items[7].completedTime }  else { completedTime8 = "N/A"}
      if (data.Items[8]) { completedTime9 = data.Items[8].completedTime }  else { completedTime9 = "N/A"}
      if (data.Items[9]) { completedTime10 = data.Items[9].completedTime }  else { completedTime10 = "N/A"}
      let leaderBoardController = {
        view: () => {
          return m("div", {class: "flex-container"}, [
            m("h1", "前 10 排名:"),
            m("h1", "---------------------------"),
            m("h1", "1 - "+completedTime1+" 秒" ),
            m("h1", "2 - "+completedTime2+" 秒" ),
            m("h1", "3 - "+completedTime3+" 秒" ),
            m("h1", "4 - "+completedTime4+" 秒" ),
            m("h1", "5 - "+completedTime5+" 秒" ),
            m("h1", "6 - "+completedTime6+" 秒" ),
            m("h1", "7 - "+completedTime7+" 秒" ),
            m("h1", "8 - "+completedTime8+" 秒" ),
            m("h1", "9 - "+completedTime9+" 秒" ),
            m("h1", "10 - "+completedTime10+" 秒" ),
            m("h1", "---------------------------"),
          ])
        }
      }
      m.mount(document.body, leaderBoardController)
      });

    }, 1000)
