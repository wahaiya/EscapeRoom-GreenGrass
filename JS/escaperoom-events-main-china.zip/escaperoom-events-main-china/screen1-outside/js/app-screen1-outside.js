let active = []

let showCountdown = "hidden";
let showDemo = "visible";
let iFrameURL = "./modules/clock/index.html";
let iframeLeaderBoardURL = "./modules/leaderboard/index.html";
let iFrameChallengesURL = "./modules/challenges/index.html";
let iFrameCountdownURL = "";


function connect() {
  var connection = new WebSocket('wss://6n5wzcue6h.execute-api.ap-northeast-1.amazonaws.com/production');
  connection.onopen = function() {
    console.log("Reconnected, connection is open and ready to use");
    };
  };

var connection = new WebSocket('wss://6n5wzcue6h.execute-api.ap-northeast-1.amazonaws.com/production');
connection.onopen = function () {
  console.log("connection is open and ready to use");
};

connection.onclose = function (error) {
  console.log('Socket is closed. Reconnect will be attempted in 1 second.', error.reason);
    setTimeout(function() {
      connect();
    }, 1000);
};

connection.onerror = function (error) {
  console.log('Socket is on error state. Reconnect will be attempted in 1 second.', error.reason);
    setTimeout(function() {
      connect();
    }, 1000);
};


let boothFrameController = {
  view: () => {
    return m("div", {class: "flex-container"}, [
      m("div", {style: {float: "left", width: "50%", visibility: showDemo}}, [
        m("iframe", {id: "iframeLeaderBoard", src: iframeLeaderBoardURL, scrolling:"no", frameBorder:"0" ,style: 'left:100px;top:0px;height:1200px;width:750px;position:relative'}),
      ]),
      m("div", {style: {float: "left", width: "50%",visibility: showDemo}}, [
        m("iframe", {id: "iframeChallenges", src: iFrameChallengesURL, allow:"camera;microphone", scrolling:"no", frameBorder:"0" ,style: 'left:0px;top:0px;height:600px;width:750px;position:relative'}),
      ]),
      m("div", {style: {float: "right", width: "50%", visibility: showCountdown}}, [
        m("iframe", {id: "iframeCountDown", src: iFrameCountdownURL, scrolling:"no", frameBorder:"0" ,style: 'left:100px;top:0px;height:600px;width:750px;position:relative'}),
      ]),
    ])
  }
}

connection.onopen = function () {
  console.log("connection is open and ready to use")
  setInterval(() => {
    connection.send(`{"type":"ping","message":"ping"}`);
  }, 3000)
};

connection.onerror = function (error) {
  console.log("an error occurred when sending/receiving data")
};

connection.onmessage = (message) => {
  try {
    console.log(message.data);
    if(message.data == "switchCode"){  
        showDemo = "visible"; 
        showCountdown = "visible"; 
        iframeLeaderBoardURL = "./modules/leaderboard/index.html";
        iFrameChallengesURL = "./modules/challenges/index.html";
        iFrameCountdownURL = "./modules/countdown/index.html";
        m.redraw();
      return; 
    } 
    if(message.data == "Reset"){  
      showDemo = "visible"; 
      showCountdown = "hidden"; 
      iFrameURL = "./modules/clock/index.html";
      iFrameCountdownURL = "";
      window.location.reload();
      m.redraw();
    return; 
  } 
  if(message.data == "challengeCompleted"){  
    showDemo = "visible"; 
    iFrameURL = "./modules/challenge-completed/index.html";
    challenge1 = "Completed";
    challenge2 = "Completed";
    challenge3= "Completed";
    challenge4= "Completed";
    challengeGameFinish= "Game Completed";
    iFrameCountdownURL = "";
    m.redraw();
  return; 
  } 
  
    
  } catch (e) {
    console.log('This doesn\'t look like a valid JSON: ',
      message.data);
    return;
  }
}



m.mount(document.body, boothFrameController, {active})
