let active = []

let showCountdown = "hidden";
let showDemo = "visible";
let iFrameURL = "./modules/clock/index.html";
let iFrameCountdownURL = "";

function resetGame() {
  showDemo = "visible"; 
  iFrameURL = "./modules/clock/index.html";
  iFrameCountdownURL = "";
  window.location.reload();
  m.redraw();
}

function connect() {
  var connection = new WebSocket('wss://6n5wzcue6h.execute-api.ap-northeast-1.amazonaws.com/production');
  connection.onopen = function() {
    console.log("Reconnected, connection is open and ready to use");
    };
  };

var connection = new WebSocket('wss://6n5wzcue6h.execute-api.ap-northeast-1.amazonaws.com/production');
connection.onopen = function () {
  console.log("connection is open and ready to use");
};

connection.onclose = function (error) {
  console.log('Socket is closed. Reconnect will be attempted in 1 second.', error.reason);
    setTimeout(function() {
      connect();
    }, 1000);
};

connection.onerror = function (error) {
  console.log('Socket is on error state. Reconnect will be attempted in 1 second.', error.reason);
    setTimeout(function() {
      connect();
    }, 1000);
};

window.allowPasscodeScreen =  false;
window.allowCelebrityScreen =  false;
window.allowTriviaScreen =  false;


let boothFrameController = {
  view: () => {
    return m("main", [
      m("div", {id: 'map', style: {display: "block", visibility: showCountdown}}, [
        m("iframe", {id: "iframeCountDown", src: iFrameCountdownURL, scrolling:"no", frameBorder:"0" ,style: 'left:1200px;top:0px;height:200px;width:500px;position:relative'}),
      ]),
      m("div", {id: 'map', style: {display: "block", visibility: showDemo}}, [
        m("iframe", {id: "iframe", src: iFrameURL, allow:"camera;microphone", scrolling:"no", frameBorder:"0" ,style: 'left:0px;top:0px;height:850px;width:1900px;position:relative'}),
      ]),
      //m("hr"),
      //m("h1", {class: "title", style: {visibility: showDemo}}, "Comprehend Chat: Scan the QR Code and test the demo"), 
      //m("video", {src:'img/horizontalscreen/horizontal-video.mp4', autoPlay:"", loop:"true", muted:"true", hidden:!showVideo}),
    ])
  }
}

connection.onopen = function () {
  console.log("connection is open and ready to use")
  setInterval(() => {
    connection.send('mainScreen');
  }, 3000)
};

connection.onerror = function (error) {
  console.log("an error occurred when sending/receiving data")
};

connection.onmessage = (message) => {
  try {
    console.log(message.data);
    if(message.data == "Passcode"){  
      window.allowCelebrityScreen = true;
      if(window.allowPasscodeScreen == true){
        showDemo = "visible"; 
        iFrameURL = "./modules/password/index.html";
        window.allowPasscodeScreen =  false;
        m.redraw();
      }
      return; 
    } 
    if(message.data == "Reset"){  
      showDemo = "visible"; 
      iFrameURL = "./modules/clock/index.html";
      iFrameCountdownURL = "";
      window.location.reload();
      m.redraw();
    return; 
  } 
  if(message.data == "Celebrity"){  
    if(window.allowCelebrityScreen == true){
    showDemo = "visible"; 
    iFrameURL = "./modules/celebrity-rekognition/index.html";
    window.allowCelebrityScreen = false;
    window.allowTriviaScreen = true;
    m.redraw();
    }
  return; 
  } 
  if(message.data == "OK - Authorized Personnel Detected"){  
    if(window.allowTriviaScreen == true){
      showDemo = "visible"; 
      iFrameURL = "./modules/trivia/index.html";
      window.allowTriviaScreen = false;
      m.redraw();
    }
  return; 
  } 
  if(message.data == "timeUp"){  
    showDemo = "visible"; 
    showCountdown = "hidden"; 
    iFrameURL = "./modules/timeisup/index.html";
    m.redraw();
    setInterval(resetGame, 60000);
  return; 
  } 
  if(message.data == "challengeCompleted"){  
    showDemo = "visible"; 
    showCountdown = "hidden"; 
    iFrameURL = "./modules/challenge-completed/index.html";
    m.redraw();
    setInterval(resetGame, 60000);
  return; 
  } 
  if(message.data == "switchCode"){  
    showDemo = "visible"; 
    showCountdown = "visible"; 
    iFrameURL = "./modules/clock/index.html";
    iFrameCountdownURL = "./modules/countdown/index.html";
    window.allowPasscodeScreen =  true;
    m.redraw();
  return; 
  } 
    
  } catch (e) {
    console.log(e);
    return;
  }
}



m.mount(document.body, boothFrameController, {active})
