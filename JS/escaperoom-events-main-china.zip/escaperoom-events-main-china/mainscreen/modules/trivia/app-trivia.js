function connect() {
  var connection = new WebSocket('wss://6n5wzcue6h.execute-api.ap-northeast-1.amazonaws.com/production');
  connection.onopen = function() {
    console.log("Reconnected, connection is open and ready to use");
    };
};

var connection = new WebSocket('wss://6n5wzcue6h.execute-api.ap-northeast-1.amazonaws.com/production');
connection.onopen = function () {
  console.log("connection is open and ready to use");
};

connection.onclose = function (error) {
  console.log('Socket is closed. Reconnect will be attempted in 1 second.', error.reason);
    setTimeout(function() {
      connect();
    }, 1000);
};

connection.onerror = function (error) {
  console.log('Socket is on error state. Reconnect will be attempted in 1 second.', error.reason);
    setTimeout(function() {
      connect();
    }, 1000);
};

async function fetchEscapeRoomData() {
  const response = await fetch('https://u0opoq2u64.execute-api.ap-northeast-1.amazonaws.com/getQuestions', {
        method: "GET", // POST
        mode: "cors",
        cache: "no-cache",
  }
  );
  const data = await response.json();
  return data;
} 

fetchEscapeRoomData().then(data => {
  console.log(data.Items);
  questionsAmount = data.Count-1;
  questionBody = "正确回答3个问题以完成挑战";
  questionStatus = "";
  currentQuestion = 999;
  questionsRight = 0;
  
  let escapeRoomController = {
    view: () => {
      return m("main", [
          m("div", [
            m("h1", questionBody),
            m("h2", questionStatus),
          ]),
      ])
    }
  } 

connection.onmessage = (message) => {
  try {
    console.log("questionsAmount " + questionsAmount);
    console.log("currentQuestion " + currentQuestion);
    console.log(message.data);
    if(message.data == "nextQuestion"){  
      currentQuestion = 0;
      questionBody = data.Items[currentQuestion].questionBody;
      m.redraw();
      questionStatus = "";
      return; 
    } 
    if(message.data == "questionRight"){  
      questionStatus = "Right!";
      m.redraw();
      setTimeout(() => {
        currentQuestion = currentQuestion + 1;
        if (currentQuestion > questionsAmount) { 
          currentQuestion = 0;
          console.log("Questions roundtrip");
        }
        questionBody = data.Items[currentQuestion].questionBody;
        questionsRight = questionsRight + 1;
        if (questionsRight === 3) {
          return;
        }
        console.log("questions right");
        m.redraw();
        questionStatus = "";
      }, 2500);
      return;
    } 
    if(message.data == "questionWrong"){  
      questionStatus = "Wrong! Try Again";
      m.redraw();
      setTimeout(() => {
        currentQuestion = currentQuestion + 1;
        if (currentQuestion > questionsAmount) { 
          currentQuestion = 0;
          console.log("Questions roundtrip");
        }
        questionBody = data.Items[currentQuestion].questionBody;
        m.redraw();
        questionStatus = "";
      }, 2500);
    return; 
    } 
  } catch (e) {
    console.log(e);
    return;
  }
}
m.mount(document.body, escapeRoomController)
});