setInterval(function () {
  async function fetchEscapeRoomData() {
    const response = await fetch('https://u0opoq2u64.execute-api.ap-northeast-1.amazonaws.com/getEscapeRoomStatus', {
          method: "GET", // POST
          mode: "cors",
          cache: "no-cache",
    }
    );
    const data = await response.json();
    //const data = await response;
    return data;
  }    
  fetchEscapeRoomData().then(data => {
    //console.log(data.Items);
    var cameraImage = JSON.parse(data.Items[0].image)
    //console.log(cameraImage)
    let escapeRoomController = {
      view: () => {
        return m("main", [
            m("div", [
                m("img", {width:"75%",height:"75%", src: "data:image/jpg;base64,"+cameraImage}),
            ]),
        ])
      }
    }
    m.mount(document.body, escapeRoomController)
    });
    
  }, 500)
    